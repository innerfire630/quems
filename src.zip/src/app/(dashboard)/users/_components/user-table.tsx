// =============================================================================
// src/app/(dashboard)/users/_components/user-table.tsx — User data table (1.3.3)
// =============================================================================

'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Can } from '@/components/can';
import { PERMISSION_USER_DELETE, PERMISSION_USER_MANAGE } from '@/lib/permissions';
import { MoreHorizontal, Pencil, UserX, Trash2, KeyRound } from 'lucide-react';
import type { UserListItem } from '@/types/user.types';

interface UserTableProps {
  users: UserListItem[];
  isLoading?: boolean;
  error?: string | null;
  onEdit?: (userId: string) => void;
  onDeactivate?: (userId: string) => void;
  onDelete?: (userId: string) => void;
  onResetPassword?: (userId: string) => void;
}

function statusClasses(status: string): string {
  switch (status) {
    case 'ACTIVE':
      return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400';
    case 'INACTIVE':
      return 'bg-amber-500/15 text-amber-700 dark:text-amber-400';
    case 'SUSPENDED':
      return 'bg-red-500/15 text-red-700 dark:text-red-400';
    default:
      return '';
  }
}

function statusLabel(status: string): string {
  return status.charAt(0) + status.slice(1).toLowerCase();
}

function relativeTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60_000);
  const diffHrs = Math.floor(diffMs / 3_600_000);
  const diffDays = Math.floor(diffMs / 86_400_000);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHrs < 24) return `${diffHrs}h ago`;
  if (diffDays < 30) return `${diffDays}d ago`;
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(date);
}

function SkeletonRow() {
  return (
    <TableRow>
      {Array.from({ length: 5 }).map((_, i) => (
        <TableCell key={i}>
          <div className="h-4 w-24 animate-pulse rounded bg-muted" />
        </TableCell>
      ))}
      <TableCell>
        <div className="h-8 w-8 animate-pulse rounded bg-muted" />
      </TableCell>
    </TableRow>
  );
}

export function UserTable({
  users,
  isLoading,
  error,
  onEdit,
  onDeactivate,
  onDelete,
  onResetPassword,
}: UserTableProps) {
  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <div className="rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Username</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Roles</TableHead>
              <TableHead>Updated</TableHead>
              <TableHead className="w-12" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array.from({ length: 5 }).map((_, i) => (
              <SkeletonRow key={i} />
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }

  if (users.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-16">
        <p className="text-sm text-muted-foreground">No users yet.</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Roles</TableHead>
            <TableHead>Updated</TableHead>
            <TableHead className="w-12" />
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
              <TableCell className="font-medium">{user.name}</TableCell>
              <TableCell className="text-muted-foreground">{user.username}</TableCell>
              <TableCell>
                <Badge variant="secondary" className={statusClasses(user.status)}>
                  {statusLabel(user.status)}
                </Badge>
              </TableCell>
              <TableCell>
                <div className="flex flex-wrap gap-1">
                  {user.roles.map((role) => (
                    <Badge key={role.id} variant="outline" className="text-xs">
                      {role.name}
                    </Badge>
                  ))}
                </div>
              </TableCell>
              <TableCell className="text-muted-foreground text-sm">
                {relativeTime(user.updatedAt)}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger className="inline-flex size-8 items-center justify-center rounded-lg hover:bg-accent">
                    <MoreHorizontal className="size-4" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit?.(user.id)}>
                      <Pencil className="mr-2 size-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onResetPassword?.(user.id)}>
                      <KeyRound className="mr-2 size-4" />
                      Reset Password
                    </DropdownMenuItem>
                    {!user.roles.some((r) => r.name === 'ADMIN') && (
                      <>
                        <Can permission={PERMISSION_USER_DELETE}>
                          <DropdownMenuItem
                            onClick={() => onDeactivate?.(user.id)}
                            disabled={user.status === 'INACTIVE'}
                            className="text-destructive focus:text-destructive"
                          >
                            <UserX className="mr-2 size-4" />
                            Deactivate
                          </DropdownMenuItem>
                        </Can>
                        <Can permission={PERMISSION_USER_MANAGE}>
                          <DropdownMenuItem
                            onClick={() => onDelete?.(user.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 size-4" />
                            Delete
                          </DropdownMenuItem>
                        </Can>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
